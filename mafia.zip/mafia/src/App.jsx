
import './index.css';
import { Nav } from './components/Navs';
import { Header } from './components/Header';
import { MafPlayer } from './components/MafPlayer';

const App = () => {
  return (
    <div className="kometa-ui">
      <Nav />
      <header>
        <Header />
      </header>
      <main>
        <MafPlayer />
      </main>
    </div>
  );
}


export default App;

import '../index.css';
import { Nav } from './Navs';
import { useRouteError } from "react-router-dom";

export default function ErrorPage() {
  const error = useRouteError();
  console.error(error);

  return (
    <div id="error-page">
      <Nav />
      <header>
        
      </header>
      <main>
        <div className="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
            <div className="max-w-screen-sm sm:text-center sm:mx-auto">
                <a
                href="/"
                aria-label="index"
                className="inline-block mb-5 rounded-full sm:mx-auto"
                >
                <div className="flex items-center justify-center w-16 h-16 mb-4 rounded-full bg-indigo-50">
                    <svg fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <linearGradient id="a" x1="12.13" x2="12.13" y1="2.302" y2="21.7" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#e2b0ff" offset="0"/>
                    <stop stop-color="#9f44d3" offset="1"/>
                    </linearGradient>
                    <g fill="#000">
                    <path d="m9.32011 15.58c-.14909.0019-.29536-.0408-.42011-.1224-.12476-.0817-.22235-.1986-.28031-.336s-.07365-.2889-.04508-.4353c.02858-.1463.10012-.2808.2055-.3863l5.65999-5.66004c.1406-.14045.3312-.21934.53-.21934.1987 0 .3894.07889.53.21934.0707.06895.127.15137.1654.24239.0384.09103.0582.18882.0582.28761 0 .0988-.0198.19659-.0582.28762-.0384.09102-.0947.17344-.1654.24238l-5.64999 5.66004c-.06924.0701-.15179.1257-.2428.1635-.09102.0377-.18866.057-.2872.0565z"/>
                    <path d="m15.0001 15.58c-.0985.0005-.1962-.0187-.2872-.0565s-.1736-.0934-.2428-.1635l-5.68999-5.66001c-.14045-.14063-.21934-.33125-.21934-.53 0-.19876.07889-.38938.21934-.53.14357-.1387.33538-.21622.535-.21622s.39144.07752.535.21622l5.64999 5.66001c.0708.069.127.1514.1654.2424s.0582.1888.0582.2876-.0198.1966-.0582.2876c-.0384.0911-.0946.1735-.1654.2424-.1319.1353-.3111.2142-.5.22z"/>
                    <path d="m12.1401 21.7c-.1303.0023-.2586-.0324-.37-.1l-7.76998-4.48c-.11502-.0652-.21075-.1597-.27748-.2739-.06674-.1141-.1021-.2439-.10252-.3761v-8.94002c.00042-.13223.03578-.26199.10252-.37614.06673-.11415.16246-.20863.27748-.27386l7.76998-4.48c.1146-.06393.2437-.09749.375-.09749s.2603.03356.375.09749l7.75 4.48c.1138.06571.2081.16057.2732.27481.065.11424.0984.24374.0968.37519v8.94002c.0016.1314-.0318.261-.0968.3752-.0651.1142-.1594.2091-.2732.2748l-7.75 4.48c-.1155.0665-.2467.101-.38.1zm-6.99998-5.7 6.99998 4 7-4v-8.00002l-7-4-6.99998 4z"/>
                    </g>
                    </svg>
                </div>
                </a>
                <h2 className="mb-4 font-sans text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl sm:leading-none">
                Похоже такой страницы не существует!
                </h2>
                <p className="text-base text-gray-700 md:text-lg sm:px-4">
                Воспользуйтесь навигацией сверху экрана.
                </p>
                <hr className="w-full my-8 border-gray-300" />
            </div>
        </div>
      </main>
    </div>
  );
}
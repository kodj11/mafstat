import React, { } from "react";
import axios from 'axios';

var server_ip = '90.156.224.228';

import {
    Navigate ,
    useLocation
  } from "react-router-dom";
export const setToken = (token) =>{
    // set token in localStorage
    localStorage.setItem('mafiaToken', token)
}
export const fetchToken = (token) =>{
    // fetch the token
    return localStorage.getItem('mafiaToken')
}
export function RequireToken() {
     
    let auth = fetchToken()
    let location = useLocation();
    if (auth == null) {
      return <Navigate to="/" state={{ from: location }} />;
    }
    axios.post(`http://${server_ip}:8000/api/tokencheck`, {
        auth
    }, {
        headers: {
          'Content-Type': 'text/plain'
        }
      })
    .then(function (response) {
        console.log(response);
        if (response.data["login_error"]=="Несуществующий токен.") {
          auth = false;
          localStorage.removeItem('mafiaToken');
        }else { 
            if(response.data['login_result']){
                auth = true;
            }
        }
    })
    .catch(function (error) {
        console.log(error, 'error');
        auth = false;
        localStorage.removeItem('mafiaToken');
    });
    if (!auth) {
      return <Navigate to="/" state={{ from: location }} />;
    }
   
}
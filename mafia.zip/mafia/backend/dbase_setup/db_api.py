from dbase_setup.auto import auto_main
import mysql.connector
import hashlib
import re

host, username, password = auto_main()

def is_valid_email(login):
    regex = re.compile(r'([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+')
    if re.fullmatch(regex, login) == 'None' or re.fullmatch(regex, login) == None:
        return 0
    else:
        return 1

def check_login(login, login_username, host=host, username=username, password=password):
    if not is_valid_email(login):
        return -1
    # Подключение к базе данных
    cnx = mysql.connector.connect(
        user=username,
        password=password,
        host=host
    )
    cursor = cnx.cursor(buffered=True)
    
    # Переключение на БД мафии
    cursor.execute("USE mafia;")
    
    # Проверяем, есть ли такая почта в базе данных
    cursor.execute("SELECT * FROM users WHERE login = %s;", (login,))
    # Получаем результат запроса
    result = cursor.fetchone()
    # Если результат не пустой, значит почта уже существует
    if result:
        cursor.close()
        cnx.close()
        return -2 # запрещаем регистрацию
    else:
        # Проверяем, есть ли такой логин в базе данных
        cursor.execute("SELECT * FROM users WHERE username = %s;", (login_username,))
        # Получаем результат запроса
        result = cursor.fetchone()
        # Если результат не пустой, значит почта уже существует
        if result:
            cursor.close()
            cnx.close()
            return -3 # запрещаем регистрацию
        else:
            cursor.close()
            cnx.close()
            return True
    

def check_logpas(login, login_password, host=host, username=username, password=password):
    # Подключение к базе данных
    cnx = mysql.connector.connect(
        user=username,
        password=password,
        host=host
    )
    cursor = cnx.cursor(buffered=True)
    
    # Переключение на БД мафии
    cursor.execute("USE mafia;")

    # Проверяем, есть ли логин и пароль в базе данных
    cursor.execute("SELECT * FROM users WHERE (login = %s AND password = %s) OR (username = %s AND password = %s)", (login, login_password, login, login_password))

    # Получаем результат запроса
    result = cursor.fetchone()

    # Закрываем курсор и соединение
    cursor.close()
    cnx.close()
    # Если результат не пустой, значит логин и пароль совпадают
    return result

def add_logpas(login, login_username, login_password, jwt, host=host, username=username, password=password):
    # Подключение к базе данных
    cnx = mysql.connector.connect(
        user=username,
        password=password,
        host=host
    )
    cursor = cnx.cursor(buffered=True)
    
    # Переключение на БД мафии
    cursor.execute("USE mafia;")

    # Шифруем пароль
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    # Добавляем логин и зашифрованный пароль в базу данных
    cursor.execute("INSERT INTO users (login, username, password, jwt) VALUES (%s, %s, %s, %s)", (login, login_username, password_hash, jwt))
    
    # Сохраняем изменения
    cnx.commit()

    # Закрываем курсор и соединение
    cursor.close()
    cnx.close()

    return True

def update_jwt(login, jwt):
    # Подключение к базе данных
    cnx = mysql.connector.connect(
        user=username,
        password=password,
        host=host
    )
    cursor = cnx.cursor(buffered=True)
    
    # Переключение на БД мафии
    cursor.execute("USE mafia;")

    cursor.execute("UPDATE users SET jwt = %s WHERE login = %s OR username = %s", (jwt, login, login))
    cnx.commit()

    # Закрываем курсор и соединение
    cursor.close()
    cnx.close()

    return True

def check_jwt(login):
    # Подключение к базе данных
    cnx = mysql.connector.connect(
        user=username,
        password=password,
        host=host
    )
    cursor = cnx.cursor(buffered=True)
    
    # Переключение на БД мафии
    cursor.execute("USE mafia;")

    cursor.execute("SELECT jwt FROM users WHERE login = %s OR username = %s", (login, login))
    
    result = cursor.fetchone()
    
    # Закрываем курсор и соединение
    cursor.close()
    cnx.close()
    if result:
        return result[0]
    else:
        return False

def check_token(token):
    # Подключение к базе данных
    cnx = mysql.connector.connect(
        user=username,
        password=password,
        host=host
    )
    cursor = cnx.cursor(buffered=True)
    
    # Переключение на БД мафии
    cursor.execute("USE mafia;")
    print('let check')
    cursor.execute("SELECT * FROM users WHERE jwt = %s", (token,))
    result = cursor.fetchone()
    print('res: ', result) 
    # Закрываем курсор и соединение
    cursor.close()
    cnx.close()
    
    if result:
        return True
    else:
        return False
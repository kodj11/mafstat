from fastapi import FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware
import json
import jwt #pip install pyjwt https://pypi.org/project/PyJWT/
from pydantic import BaseModel
from fastapi.encoders import jsonable_encoder
from fastapi import Body

import sys
sys.path.append('.. /dbase_setup') 
from dbase_setup.db_api import check_login, check_logpas, add_logpas, update_jwt, check_jwt, check_token

app = FastAPI() 

origins = [
    "https://localhost:3000",
    "http://localhost:8000",
    "http://localhost:3000",
    "http://90.156.224.228:3000",
    "http://90.156.224.228",
    "http://mgatti.ru",
    "https://90.156.224.228",
    "https://mgatti.ru"
]

SECRET_KEY = "3Kr0IS4oDlJy05QPoUdHlo1o7VbFRss3SYDACLBzm6c="
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 800

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Tokenclass(BaseModel):
    token: str

class Entryclass(BaseModel):
    username: str
    password: str

class Regclass(BaseModel):
    email: str
    username: str
    password: str

@app.post("/api/reg")
async def check_reg(data: Regclass):
    reg = jsonable_encoder(data)
    try:
        email    = reg["email"]
        login    = reg["username"]
        password = reg["password"]
        check = check_login(email, login)
        if check == -1:
            return {
                "reg_error": { "Несуществующая почта!" }
            }
        elif check == -3:
            return {
                "reg_error": { "Такой логин уже используется!" }
            }
        elif check == -2:
            return {
                "reg_error": { "Такая почта уже используется!" }
            }
        else:
            data = jsonable_encoder(data)
            encoded_jwt = jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)
            add_logpas(email, login, password, encoded_jwt)

    except Exception as e:
        print('Приём рег данных: ', e)
        return {
            "reg_error": { "Ошибка входа." }
        }
    return {
        "reg": { "Зарегистрирован!" },
        "token": encoded_jwt
    }

@app.post("/api/login")
async def login_user(login_item: Entryclass):
    data = jsonable_encoder(login_item)
    print(data)
    try:
        if check_logpas(data["username"],data["password"]):
            print('good')
            current_jwt = check_jwt(data["username"])
            if current_jwt:
                return {'token': current_jwt }
            encoded_jwt = jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)
            update_jwt(data["username"], encoded_jwt)
            return {'token': encoded_jwt }
        else:
            return {'login_error': 'Неверный логин или пароль'}
    except Exception as e:
        print('login error:', e)

@app.post("/api/tokencheck")
async def token_check(token: str = Body(..., media_type="text/plain")):
    token = json.loads(token)
    print(token["auth"])
    try:
        if check_token(token["auth"]):
            print('good')
            return {'login_result': 'good' }
        else:
            return {'login_error': 'Несуществующий токен.'}
    except Exception as e:
        print('login error:', e)
import mysql.connector
from getpass import getpass

def create_database(host, username, password):
    try:
        # Подключение к базе данных
        cnx = mysql.connector.connect(
            user=username,
            password=password,
            host=host
        )
        cursor = cnx.cursor()
        # Создание базы данных
        cursor.execute("CREATE DATABASE IF NOT EXISTS mafia;")
        print(f"База данных mafia создана или уже существует.")
        # Переключение на БД мафии
        cursor.execute("USE mafia;")
        # Создаём таблицу для входа пользователей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT,
                login VARCHAR(255) NOT NULL,
                username VARCHAR(100) NOT NULL,
                password VARCHAR(255) NOT NULL,
                jwt VARCHAR(511),
                PRIMARY KEY (id)
            ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
        ''')
        print(f"Таблица users создана или уже существует.")
        # Закрытие соединения
        cursor.close()
        cnx.close()
    except mysql.connector.Error as err:
        print(f"Ошибка создания базы данных: {err}")

def auto_main():
    host = input("Введите хост (по умолчанию localhost): ") or 'localhost'
    username = input("Введите логин: ")
    password = getpass("Введите пароль: ")
    
    create_database(host, username, password)
    return host, username, password
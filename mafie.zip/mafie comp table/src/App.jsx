
import './index.css';
import { Nav } from './components/Navs';
import { Header } from './components/Header';
import { MafPlayer } from './components/MafPlayer';
import React from 'react';

const App = () => {
  return (
    <div className="kometa-ui">
      <Nav />
      <Header />
      <MafPlayer />
    </div>
  );
}

export default App;

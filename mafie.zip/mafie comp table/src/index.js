import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import "./styles/tailwind.css";
import App from './App';
import Rules from './components/Rules';
import Login from './components/LoginPage';
import Reg from './components/RegPage';
import UserProfile from './components/UserProfile';
import { Wantplay } from './components/WantPlay';
import { Table } from './components/Stol';
import ErrorPage from './components/Error-page';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";



const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <ErrorPage />,
  },
  {
    path: "/rules",
    element: <Rules />,
  },
  {
    path: "/entry",
    element: <Login />,
  },
  {
    path: "/reg",
    element: <Reg />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/profile",
    element: <UserProfile />,
  },
  {
    path: "/wantplay",
    element: <Wantplay />,
  },
  {
    path: "/table",
    element: <Table />,
  },
]);


const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
import React, { useState } from 'react';
import axios from 'axios';
import {useNavigate} from "react-router-dom";
import {setToken} from './Auth.js' //, fetchToken
import '../index.css';

import { Nav } from './Navs.js';
import EmojiBackground from './EmojiBackground';

 

export default function Login(){
    const navigate = useNavigate();
    const [login,setUsername] = useState('');
    const [password,setPassword] = useState('');
  
    const handleSubmit = (event) => {
        event.preventDefault();
        if(login.length === 0){
          alert("Почему логин пустой?!");
          return;
        } 
        else if(password.length <= 5){
          alert("Пароль слишком короткий!");
          return;
        }
        else{
            var server_ip = 'localhost';
            console.log('axios')
            axios.post(`http://${server_ip}:8000/api/login`, {
                username: login,
                password: password
            })
            .then(function (response) {
                console.log(response);
                if (response.data["entry_error"] === "Login failed") {
                    alert("Login failed");
                }else { 
                    if(response.data.token){
                        setToken(response.data.token)
                        navigate("/profile");
                    }
                }
            })
            .catch(function (error) {
                console.log(error, 'error');
            });
        }
    }
  return (
    <div className="kometa-ui">
      <EmojiBackground />
      <Nav />
      <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-1 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">
          <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
            Вход в аккаунт
          </h2>
        </div>

        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium leading-6 text-gray-900">
                Почта или логин
              </label>
              <div className="mt-2">
                <input
                  id="login"
                  name="login"
                  type="email"
                  required
                  autoComplete="email"
                  value={login} 
                  onChange={(e) => setUsername(e.target.value)}
                  className="block w-full rounded-md border-spacing-2 px-2 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-red-600 sm:text-2xl sm:leading-6"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="block text-sm font-medium leading-6 text-gray-900">
                  Пароль
                </label>
                <div className="text-sm">
                  <a href="forget" className="font-semibold text-red-300 hover:text-red-600">
                    Забыли пароль?
                  </a>
                </div>
              </div>
              <div className="mt-2">
                <input
                  
                  type="password"
                  required
                  autoComplete="current-password"
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full rounded-md border-spacing-2 px-2 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-red-600 sm:text-2xl sm:leading-6"
                />
              </div>
            </div>

            <div>
              <button
                
                onClick={handleSubmit}
                className="flex w-full justify-center rounded-md bg-red-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-red-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600"
              >
                Войти
              </button>
            </div>
          </form>

          <p className="mt-5 text-center text-xs text-gray-500">
            Впервые тут?{' '}
            <a href="reg" className="font-semibold leading-5 text-red-300 hover:text-red-600">
              Пройти регистрацию
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
import '../index.css';
import React from 'react';

export const MafPlayer = () => {
    return (
      <div className="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
        <div className="flex flex-col mb-6 lg:justify-between lg:flex-row md:mb-8">
          <h2 className="max-w-lg mb-5 font-sans text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl sm:leading-none md:mb-6 group">
            <span className="inline-block mb-1 sm:mb-4">
            Роли в            
              
            спортивной мафии
            </span>
            <div className="h-1 ml-auto duration-300 origin-left transform bg-red-800 scale-x-30 group-hover:scale-x-100" />
          </h2>
          <p className="text-gray-700 lg:text-sm lg:max-w-md">
          В игре принимают участие десять человек. Игроки случайным образом делятся на две команды: «красные» (мирные жители) и «чёрные» (мафия). 
          В игре разыгрываются 7 «красных» карт, одна из которых — Шериф, и 3 «чёрные», одна из которых — Дон.
          </p> 
        </div> 
        <div className="grid gap-6 row-gap-5 mb-8 lg:grid-cols-4 sm:row-gap-6 sm:grid-cols-2">
            <div className="relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:-translate-y-2 hover:shadow-2xl">
              <img
                className="object-cover w-full h-56 md:h-64 xl:h-80"
                src="https://i.ibb.co/7NRdZGg/DON.webp"
                alt="Дон мафии"
              />
              <div className="absolute inset-0 px-6 py-4 transition-opacity duration-200 bg-black bg-opacity-75 opacity-0 hover:opacity-100">
                <p className="mb-4 text-lg font-bold text-gray-100">Дон</p>
                <p className="text-sm tracking-wide text-gray-300">
                Дон - глава мафии, который имеет доступ к дополнительной информации и может каждую ночь узнавать у ведущего, 
                является ли определённый игрок комиссаром. Он отвечает за стратегию команды мафии и принимает решения о том, 
                кого мафия будет убивать.
                </p>
              </div>
            </div>
            <div className="relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:-translate-y-2 hover:shadow-2xl">
              <img
                className="object-cover w-full h-56 md:h-64 xl:h-80"
                src="https://i.ibb.co/KxRvcTR/BLACK.webp"
                alt="Мафия"
              />
              <div className="absolute inset-0 px-6 py-4 transition-opacity duration-200 bg-black bg-opacity-75 opacity-0 hover:opacity-100">
                <p className="mb-4 text-lg font-bold text-gray-100">
                  Черные игроки
                </p>
                <p className="text-sm tracking-wide text-gray-300">
                Мафия знакома между собой, в отличие от мирных жителей. Ночью мафиози могут убить одного игрока, 
                а днём они притворяются обычными жителями. Мафии нужно вводить город в заблуждение и казаться мирными до конца игры. 
                В игре их называют «чёрными» игроками.
                </p>
              </div>
            </div>
            <div className="relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:-translate-y-2 hover:shadow-2xl">
              <img
                className="object-cover w-full h-56 md:h-64 xl:h-80"
                src="https://i.ibb.co/XDjkD8c/SHERIFF2.webp"
                alt="Шериф"
              />
              <div className="absolute inset-0 px-6 py-4 transition-opacity duration-200 bg-black bg-opacity-75 opacity-0 hover:opacity-100">
                <p className="mb-4 text-lg font-bold text-gray-100">Комиссар</p>
                <p className="text-sm tracking-wide text-gray-300">
                Комиссар выступает на стороне мирных жителей, но у него есть особенность: он просыпается каждую ночь 
                и узнаёт роль одного из игроков от ведущего. Т.к. комиссар осведомлён о ролях участников, 
                он становится главной мишенью для мафии.
                </p>
              </div>
            </div>
            <div className="relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:-translate-y-2 hover:shadow-2xl">
              <img
                className="object-cover w-full h-56 md:h-64 xl:h-80"
                src="https://i.ibb.co/tZhg7Wc/RED2.webp"
                alt="Мирный житель"
              />
              <div className="absolute inset-0 px-6 py-4 transition-opacity duration-200 bg-black bg-opacity-75 opacity-0 hover:opacity-100">
                <p className="mb-4 text-lg font-bold text-gray-100">
                  Красные игроки
                </p>
                <p className="text-sm tracking-wide text-gray-300">
                Мирному жителю неизвестно, какие роли у других игроко. Его основная задача определить, кто из участников мирный житель, 
                а кто мафия, и проголосовать за мафию во время дневного голосования. В игровой терминологии мирного жителя называют «красным» игроком.
                </p>
              </div>
            </div>
        </div>
      </div>
    );
  };
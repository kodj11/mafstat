// contexts/dashboard-context.tsx
"use client"

import { createContext, useContext, useState, ReactNode } from "react"

interface DashboardContextType {
  content: ReactNode
  setContent: (content: ReactNode) => void
}

const DashboardContext = createContext<DashboardContextType | null>(null)

export const DashboardProvider = ({ children }: { children: ReactNode }) => {
  const [content, setContent] = useState<ReactNode>(null)

  return (
    <DashboardContext.Provider value={{ content, setContent }}>
      {children}
    </DashboardContext.Provider>
  )
}

export const useDashboard = () => {
  const context = useContext(DashboardContext)
  if (!context) {
    throw new Error("useDashboard must be used within a DashboardProvider")
  }
  return context
}
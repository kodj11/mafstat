export const Footer = () => {
  return (
    <section className=" py-5 border-t border-white/20 f0ter">
      <div className="container">
        <div className="flex flex-col md:flex-row md:justify-between gap-4">
          <div className="text-center select-none">&copy; 2025 SLI, Fayustov Nikita. 345b</div>
        </div>
      </div>
    </section>
  );
};

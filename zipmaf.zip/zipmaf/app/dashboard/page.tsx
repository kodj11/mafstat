// app/dashboard/page.tsx
"use client"

import { AppSidebar } from "@/components/app-sidebar"
import { SiteHeader } from "@/components/site-header"
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar"
import { useDashboard } from "@/contexts/dashboard-context"
import { DashboardCard } from "@/components/DashboardCard"
import { List, PlusCircle, PlayCircle } from "lucide-react"
import { GamesList } from "@/components/games-list"
import { AddGameForm } from "@/components/add-game"
import React from "react"

export default function Page() {
  const { content, setContent } = useDashboard()

  const handleAllGamesClick = React.useCallback(() => {
    setContent(<GamesList />)
  }, [setContent])

  const handleAddGameClick = React.useCallback(() => {
    setContent(<AddGameForm />)
  }, [setContent])

  const handlePlayGameClick = React.useCallback(() => {
    setContent(<div>Провести игру (заглушка)</div>)
  }, [setContent])

  const cards = [
    { icon: List, label: "Все игры", onClick: handleAllGamesClick },
    { icon: PlusCircle, label: "Добавить игру", onClick: handleAddGameClick },
    { icon: PlusCircle, label: "Добавить турнир", onClick: handleAddGameClick },
    { icon: PlayCircle, label: "Провести игру", onClick: handlePlayGameClick },
  ]

  return (
    <div className="[--header-height:calc(theme(spacing.14))]">
      <SidebarProvider className="flex flex-col">
        <SiteHeader />
        <div className="flex flex-1">
          <AppSidebar />
          <SidebarInset>
            <div className="flex flex-1 flex-col gap-4 p-4">
              {content || (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                  {cards.map((card, idx) => (
                    <DashboardCard key={idx} {...card} />
                  ))}
                </div>
              )}
            </div>
          </SidebarInset>
        </div>
      </SidebarProvider>
    </div>
  )
}
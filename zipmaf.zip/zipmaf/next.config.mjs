/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      domains: ['raw.githubusercontent.com'],
    },
    webpack(config) {
      config.module.rules.push({
        test: /\.svg$/,
        use: [{
          loader: '@svgr/webpack',
          options: {
            svgo: false, // Отключаем оптимизацию SVGO
          },
        }],
      });
  
      return config;
    },
    staticPageGenerationTimeout: 120,
  };
  
  export default nextConfig;
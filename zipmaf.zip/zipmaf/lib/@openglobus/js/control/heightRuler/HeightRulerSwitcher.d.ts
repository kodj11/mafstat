import { RulerSwitcher } from "../RulerSwitcher";
export declare class HeightRulerSwitcher extends RulerSwitcher {
    constructor(options?: {
        ignoreTerrain?: boolean;
    });
}

import { Ruler, IRulerParams } from "../ruler/Ruler";
interface IHeightRulerParams extends IRulerParams {
}
export declare class HeightRuler extends Ruler {
    constructor(options?: IHeightRulerParams);
}
export {};

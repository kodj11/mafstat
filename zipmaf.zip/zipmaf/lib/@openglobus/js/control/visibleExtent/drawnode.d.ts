import { Program } from "../../webgl/Program";
export declare function drawnode_screen_nl(): Program;
export declare function drawnode_screen_wl(): Program;
export declare function drawnode_screen_wl_webgl2(): Program;
export declare function drawnode_colorPicking(): Program;
export declare function drawnode_heightPicking(): Program;
export declare function drawnode_depth(): Program;

import { XYZ, IXYZParams } from "./XYZ";
export declare class Bing extends XYZ {
    constructor(name: string | null, options?: IXYZParams);
}

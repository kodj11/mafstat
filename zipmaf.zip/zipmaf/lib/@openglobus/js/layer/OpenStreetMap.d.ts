import { XYZ, IXYZParams } from "./XYZ";
export declare class OpenStreetMap extends XYZ {
    constructor(name: string | null, options?: IXYZParams);
}

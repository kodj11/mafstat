/**
 * @module og/proj/equi
 */
import { Proj } from "./Proj";
/**
 * Any equrectangualr projection object.
 * @type {Proj}
 */
export declare const equi: Proj;

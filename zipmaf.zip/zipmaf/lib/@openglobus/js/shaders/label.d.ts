import { Program } from '../webgl/Program';
export declare function label_webgl2(): Program;
export declare function label_screen(): Program;
export declare function labelPicking(): Program;

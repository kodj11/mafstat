import { Program } from '../webgl/Program';
export declare function polyline_screen(): Program;
export declare function polyline_picking(): Program;

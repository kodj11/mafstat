import { Program } from '../webgl/Program';
export declare function billboardPicking(): Program;
export declare function billboard_screen(): Program;

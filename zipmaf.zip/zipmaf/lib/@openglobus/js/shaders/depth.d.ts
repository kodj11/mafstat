import { Program } from '../webgl/Program';
export declare function depth(): Program;

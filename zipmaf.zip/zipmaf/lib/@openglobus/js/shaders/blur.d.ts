import { Program } from '../webgl/Program';
export declare function buildKernel(sigma: number): number[];
export declare function blur(): Program;

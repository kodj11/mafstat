import { Program } from '../webgl/Program';
export declare function rayScreen(): Program;

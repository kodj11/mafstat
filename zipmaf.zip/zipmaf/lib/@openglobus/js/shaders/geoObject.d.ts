import { Program } from "../webgl/Program";
export declare const geo_object: () => Program;
export declare const geo_object_picking: () => Program;

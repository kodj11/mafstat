import { Mat3 } from "../math/Mat3";
export declare function getRotationMatrix(rightAscension: number, declination: number, res?: Mat3): Mat3;

export declare const input: {
    [id: string]: number;
};

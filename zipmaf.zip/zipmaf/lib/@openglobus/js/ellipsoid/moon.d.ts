import { Ellipsoid } from "./Ellipsoid";
/**
 * Moon ellipsoid object.
 * @type {Ellipsoid}
 */
export declare const moon: Ellipsoid;

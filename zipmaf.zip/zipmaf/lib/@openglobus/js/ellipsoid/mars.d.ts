import { Ellipsoid } from "./Ellipsoid";
/**
 * Mars ellipsoid object.
 * @type {Ellipsoid}
 */
export declare const mars: Ellipsoid;

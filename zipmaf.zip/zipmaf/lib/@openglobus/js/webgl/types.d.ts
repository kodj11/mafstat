/**
 * @module og/webgl/types
 */
export declare const types: {
    [id: string]: number;
};
export declare const typeStr: {
    [id: string]: number;
};

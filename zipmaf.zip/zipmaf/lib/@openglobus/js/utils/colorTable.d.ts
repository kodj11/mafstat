export declare const colorTable: {
    [id: string]: string;
};

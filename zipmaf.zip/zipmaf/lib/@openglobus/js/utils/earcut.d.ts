declare function earcut(data: any, holeIndices: any, dim: any): any[];
declare function flatten(data: any): {
    vertices: never[];
    holes: never[];
    dimensions: any;
};
export { earcut, flatten };

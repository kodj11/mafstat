from fastapi import FastAPI, Response, HTTPException, Request, Depends, Header, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi.encoders import jsonable_encoder
from fastapi import Body
from fastapi.responses import JSONResponse

from typing import Optional

import json
import jwt #pip install pyjwt https://pypi.org/project/PyJWT/

import hashlib
import sys
sys.path.append('.. /dbase_setup')

from dbase_setup.db_api import check_token, get_players, get_games, add_game, search_players, get_games_filtered, get_games_count
from dbase_setup.db_api import check_login, check_logpas, add_logpas, update_jwt, check_jwt
from dbase_setup.db_api import get_player_games_by_role, get_player_wins_by_role
from dbase_setup.db_api import get_user_id_by_token, get_user_profile

from datetime import datetime, timedelta

from collections import defaultdict
import time

# Хранилище попыток: {login: [timestamps]}
login_attempts = defaultdict(list)
MAX_ATTEMPTS = 5
BLOCK_TIME = 60  # секунд

app = FastAPI() 

origins = [
    "https://localhost:3000",
    "http://localhost:8000",
    "https://localhost:8000",
    "http://localhost:3000",
    "http://mgatti.ru",
    "http://mgatti.ru:80",
    "https://mgatti.ru",
    "https://mgatti.ru:8080",
    "http://rnfzs-94-25-183-29.a.free.pinggy.link",
    "https://rnfzs-94-25-183-29.a.free.pinggy.link"
]

SECRET_KEY = "3Kr0IS4oDlJy05QPoUdHlo1o7VbFRss3SYDACLBzm6c="
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 800

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Tokenclass(BaseModel):
    token: str

class Entryclass(BaseModel):
    username: str
    password: str

class Regclass(BaseModel):
    email: str
    username: str
    password: str

class RoleStatsResponse(BaseModel):
    peaceful: int
    mafia: int
    don: int
    sheriff: int
    lead: int

class WinStatsResponse(BaseModel):
    role: str
    games: int
    wins: int

class WinStatsListResponse(BaseModel):
    stats: list[WinStatsResponse]

class UserProfileResponse(BaseModel):
    username: str
    is_admin: bool
    status: Optional[str]
    geolocation: Optional[str]
    is_open_profile: bool
    avatar: str
    contact_email: Optional[str]
    is_online: bool

# --- ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ ---
def get_device_id(request: Request) -> str:
    return request.headers.get('user-agent', 'unknown')

async def verify_token(authorization: Optional[str], request: Request):
    if not authorization or request is None:
        raise HTTPException(status_code=401, detail="Authorization header is missing or request not provided")
    try:
        token = authorization.split(" ")[1]
        device_id = get_device_id(request)
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token expired")
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token")
        if payload.get("device_id") != device_id:
            raise HTTPException(status_code=401, detail="Invalid device")
        user_data = get_user_id_by_token(token)  # возвращает user_id и is_admin
        if not user_data:
            raise HTTPException(status_code=401, detail="Invalid token")
        return user_data
    except Exception as e:
        print('verify_token error:', e)
        raise HTTPException(status_code=401, detail="Invalid token format")

# --- DEPENDS ДЛЯ FASTAPI ---
async def get_current_user(request: Request, authorization: str = Header(None)):
    return await verify_token(authorization, request)

@app.get("/api/user/{user_id}/profile", response_model=UserProfileResponse)
async def api_get_user_profile(
    user_id: int,
    user_data: dict = Depends(get_current_user)
):
    """
    Получает полную информацию о профиле пользователя по его ID
    Требуется авторизация
    Возвращает:
    - username: имя пользователя
    - is_admin: является ли администратором
    - status: статус пользователя
    - geolocation: местоположение
    - is_open_profile: открыт ли профиль
    - avatar: URL аватара
    - contact_email: контактный email
    - is_online: онлайн ли пользователь
    """
    try:
        profile = get_user_profile(user_id)
        if profile is None:
            raise HTTPException(
                status_code=404,
                detail="User not found"
            )
            
        return profile

    except HTTPException:
        raise
    except Exception as e:
        print('Error:', e)
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@app.post("/api/get-user-id-by-token")
async def api_get_user_id_by_token(authorization: Optional[str] = Header(None)):
    """
    Получает ID пользователя по токену JWT
    Возвращает:
    - ID пользователя, если токен валиден
    - -1, если токен не найден
    - 401 ошибку, если токен не предоставлен
    """
    try:
        # Проверяем токен из заголовка Authorization (если есть)
        if authorization:
            try:
                auth_token = authorization.split(" ")[1]
                user_id = get_user_id_by_token(auth_token)
                if user_id is not None:
                    return user_id
            except Exception as e:
                print('Error in get-user-id-by-token:', e)
                pass
        raise HTTPException(
            status_code=401,
            detail="Invalid token"
        )
    except HTTPException:
        raise
    except Exception as e:
        print('Error:', e)
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@app.get("/api/player/{user_id}/role-stats", response_model=RoleStatsResponse)
async def api_get_player_role_stats(
    user_id: int,
    user_data: dict = Depends(get_current_user)
):
    """
    Получает статистику игр по ролям для указанного пользователя
    Требуется авторизация
    """
    try:
        stats = get_player_games_by_role(user_id)
        if stats is None:
            raise HTTPException(
                status_code=404,
                detail="Player not found or no games played"
            )
            
        return stats

    except Exception as e:
        print('Error:', e)
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@app.get("/api/player/{user_id}/win-stats", response_model=WinStatsListResponse)
async def api_get_player_win_stats(
    user_id: int,
    user_data: dict = Depends(get_current_user)
):
    """
    Получает статистику побед по ролям для указанного пользователя
    Требуется авторизация
    Возвращает список объектов с статистикой для каждой роли
    """
    try:
        stats = get_player_wins_by_role(user_id)
        if stats is None:
            raise HTTPException(
                status_code=404,
                detail="Player not found or no games played"
            )
        
        # Преобразуем словарь в список объектов для ответа
        stats_list = [
            {"role": "peaceful", "games": stats["peaceful"]["games"], "wins": stats["peaceful"]["wins"]},
            {"role": "mafia", "games": stats["mafia"]["games"], "wins": stats["mafia"]["wins"]},
            {"role": "don", "games": stats["don"]["games"], "wins": stats["don"]["wins"]},
            {"role": "sheriff", "games": stats["sheriff"]["games"], "wins": stats["sheriff"]["wins"]},
            {"role": "lead", "games": stats["lead"]["games"], "wins": stats["lead"]["wins"]},
        ]
            
        return {"stats": stats_list}

    except Exception as e:
        print('Error:', e)
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@app.get("/api/player/{user_id}/stats")
async def api_get_player_full_stats(
    user_id: int,
    user_data: dict = Depends(get_current_user)
):
    """
    Получает полную статистику игрока (игры и победы по ролям)
    Требуется авторизация
    """
    try:
        # Получаем обе статистики
        role_stats = get_player_games_by_role(user_id)
        win_stats = get_player_wins_by_role(user_id)
        
        if role_stats is None or win_stats is None:
            raise HTTPException(
                status_code=404,
                detail="Player not found or no games played"
            )
        
        # Формируем ответ
        response = {
            "role_stats": role_stats,
            "win_stats": {
                "peaceful": win_stats["peaceful"],
                "mafia": win_stats["mafia"],
                "don": win_stats["don"],
                "sheriff": win_stats["sheriff"],
                "lead": win_stats["lead"],
            }
        }
            
        return response

    except Exception as e:
        print('Error:', e)
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@app.post("/api/add-game")
async def api_add_game(
    game_data: dict,
    user_data: dict = Depends(get_current_user)
):
    if not user_data["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    try:
        # Валидация данных
        required_fields = ["date", "winner", "participants", "players"]
        for field in required_fields:
            if field not in game_data:
                raise HTTPException(status_code=400, detail=f"Missing field: {field}")

        # Вызов функции добавления игры
        success = add_game(
            date=game_data["date"],
            winner=game_data["winner"],
            table_number=int(game_data["table"]),
            game_number=int(game_data["game_number"]),
            participants=game_data["participants"],
            lead_player_id=game_data.get("leadPlayerId"),
            best_moves=game_data.get("bestMoves", []),
            players_data=game_data["players"]
        )

        if not success:
            raise HTTPException(status_code=500, detail="Database error")

        return {"status": "success", "game_id": game_data.get("game_id")}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/search-players")
def api_search_players(query: str = Body(..., media_type="text/plain")):
    query = jsonable_encoder(query)
    print(query)
    try:
        players = search_players(query)
        print(players)
        if players is None:
            raise HTTPException(
                status_code=500,
                detail="Database error"
            )
            
        return {"players": players}

    except Exception as e:
        print('Error:', e)
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@app.post("/api/games-summary")
def api_games_summary(
    start_date: str = Body(None),
    end_date: str = Body(None)
):
    try:
        kwargs = {"offset": 0, "limit": 10000}
        if start_date:
            kwargs["start_date"] = start_date
        if end_date:
            kwargs["end_date"] = end_date
        games = get_games_filtered(**kwargs)
        return {"games": games}
    except Exception as e:
        print('Error:', e)
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/games")
def api_get_games(
    limit: int = Body(30),
    offset: int = Body(0),
    start_date: str = Body(None),
    end_date: str = Body(None),
    year: int = Body(None),
    month: int = Body(None)
):
    try:
        # Если явно передан год или месяц, вычисляем start_date и end_date
        from datetime import datetime
        import calendar
        now = datetime.now()
        # Если оба значения не заданы, используем start_date/end_date как есть
        if year is not None or month is not None:
            # Если год не задан, берем диапазон всех лет (2020-...)
            y = year if year is not None else 2020
            m = month if month is not None else 1
            # Если только месяц, то диапазон с 2020 по текущий год
            if year is None and month is not None:
                start_date = f"2020-{m:02d}-01"
                end_date = f"{now.year}-{m:02d}-{calendar.monthrange(now.year, m)[1]}"
            # Если только год, то диапазон всего года
            elif year is not None and month is None:
                start_date = f"{y}-01-01"
                end_date = f"{y}-12-31"
            # Если и год, и месяц
            elif year is not None and month is not None:
                start_date = f"{y}-{m:02d}-01"
                end_date = f"{y}-{m:02d}-{calendar.monthrange(y, m)[1]}"
        kwargs = {"offset": offset, "limit": limit}
        if start_date:
            kwargs["start_date"] = start_date
        if end_date:
            kwargs["end_date"] = end_date
        games = get_games_filtered(**kwargs)
        total = get_games_count(start_date=start_date, end_date=end_date)
        return {"games": games, "total": total}
    except Exception as e:
        print('Error:', e)
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/players")
def api_get_players():  # Убираем async для синхронного обработчика
    try:
        players = get_players()
        
        if players is None:
            return JSONResponse(
                status_code=500,
                content={"error": "Database error"}
            )
            
        return {"players": players}

    except Exception as e:
        print('Error:', e)
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error"}
        )

@app.post("/api/reg")
async def check_reg(data: Regclass, request: Request):
    reg = jsonable_encoder(data)
    try:
        email    = reg["email"]
        login    = reg["username"]
        password = reg["password"]
        check = check_login(email, login)
        if check == -1:
            return {
                "reg_error": { "Несуществующая почта!" }
            }
        elif check == -3:
            return {
                "reg_error": { "Такой логин уже используется!" }
            }
        elif check == -2:
            return {
                "reg_error": { "Такая почта уже используется!" }
            }
        else:
            data = jsonable_encoder(data)
            device_id = get_device_id(request)
            payload = data.copy()
            payload["exp"] = int((datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)).timestamp())
            payload["device_id"] = device_id
            encoded_jwt = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
            add_logpas(email, login, password, encoded_jwt)
    except Exception as e:
        print('Приём рег данных: ', e)
        return {
            "reg_error": { "Ошибка входа." }
        }
    return {
        "reg": { "Зарегистрирован!" },
        "token": encoded_jwt
    }

@app.post("/api/login")
async def login_user(login_item: Entryclass, request: Request):
    data = jsonable_encoder(login_item)
    login = data["username"]
    now = time.time()
    login_attempts[login] = [t for t in login_attempts[login] if now - t < BLOCK_TIME]
    if len(login_attempts[login]) >= MAX_ATTEMPTS:
        return {'login_error': 'Слишком много попыток входа. Попробуйте позже.'}
    try: 
        if check_logpas(data["username"], data["password"]):
            login_attempts[login] = []
            device_id = get_device_id(request)
            payload = data.copy()
            payload["exp"] = int((datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)).timestamp())
            payload["device_id"] = device_id
            encoded_jwt = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
            update_jwt(data["username"], encoded_jwt)
            return {'token': encoded_jwt }
        else:
            login_attempts[login].append(now)
            return {'login_error': 'Неверный логин или пароль'}
    except Exception as e:
        print('login error:', e)

@app.post("/api/tokencheck")
async def token_check(token: str = Body(..., media_type="text/plain")):
    token = json.loads(token)
    try:
        if check_token(token["auth"]):
            print('good')
            return {'login_result': 'good' }
        else:
            return {'login_error': 'Несуществующий токен.'}
    except Exception as e:
        print('login error:', e)



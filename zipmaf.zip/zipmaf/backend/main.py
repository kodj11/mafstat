import sys
import subprocess

REQUIRED_PACKAGES = [
    'uvicorn',
    'fastapi',
    'pydantic',
    'pyjwt',
    'hashlib',
    'time',
    'requests',
    'json',
    'datetime',
    'uuid',
    'bcrypt',
    're',
    'getpass',
    'collections',
    'typing' 
]

def install_and_import(package):
    try:
        __import__(package)
    except ImportError:
        if package == "uvicorn":
            subprocess.check_call([sys.executable, '-m', 'pip3', 'install', 'uvicorn[standard]'])
        elif package == "pyjwt":
            subprocess.check_call([sys.executable, '-m', 'pip3', 'install', 'pyjwt --break-system-packages'])
        else:
            print(f"[INFO] Installing missing package: {package}")
            subprocess.check_call([sys.executable, '-m', 'pip3', 'install', package])
        __import__(package)

for pkg in REQUIRED_PACKAGES:
    import_name = 'jwt' if pkg == 'pyjwt' else pkg
    install_and_import(import_name)

import uvicorn

if __name__ == "__main__":
    uvicorn.run("app.api:app", host="localhost", port=8000, reload=True)
 
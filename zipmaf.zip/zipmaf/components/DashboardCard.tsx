import { LucideIcon } from "lucide-react";
import React from "react";
import clsx from "clsx";

interface DashboardCardProps {
  icon: LucideIcon;
  label: string;
  onClick?: () => void;
  className?: string;
}

export const DashboardCard: React.FC<DashboardCardProps> = ({
  icon: Icon,
  label,
  onClick,
  className,
}) => (
  <button
    className={clsx(
      "flex flex-col items-center justify-center aspect-square rounded-xl bg-muted/50 hover:bg-muted transition cursor-pointer shadow-md p-6",
      className
    )}
    onClick={onClick}
    type="button"
  >
    <Icon className="w-10 h-10 mb-2 text-primary" />
    <span className="text-lg font-medium">{label}</span>
  </button>
); 
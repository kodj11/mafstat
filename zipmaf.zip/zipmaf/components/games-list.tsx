import { useEffect, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Trophy, Star, ThumbsDown, Crown, Hash, Landmark, Crosshair } from "lucide-react"; // Импортируем Crosshair
import useSWR from 'swr';
import Cookies from 'js-cookie';
import API_BASE_URL from "@/lib/server";

interface Player {
  id: number;
  nickname: string;
  role: string;
  score: number;
  is_lead: boolean;
  is_killed_first?: boolean;
}

interface Game {
  game_id: number;
  game_date: string;
  winner: string;
  table_number: number;
  game_number: number;
  players: Player[];
  best_movers?: string[];
}

export function GamesList() {
  const token = Cookies.get('mafiaToken');
  const fetcher = async (url: string, token: string, method: string = 'POST') => {
    const res = await fetch(url, {
      method,
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
    });
    if (res.status === 401) {
      Cookies.remove('mafiaToken');
      window.location.replace('/login');
      throw new Error('Unauthorized');
    }
    return res.json();
  };

  const { data, error, isLoading } = useSWR(
    token ? ['${API_BASE_URL}/api/games', token, 'POST'] : null,
    ([url, token, method]) => fetcher(url, token, method),
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
      revalidateIfStale: false,
    }
  );

  const [expandedGames, setExpandedGames] = useState<Record<number, boolean>>({});

  const toggleGameExpand = (gameId: number) => {
    setExpandedGames((prev) => ({
      ...prev,
      [gameId]: !prev[gameId],
    }));
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("ru-RU", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const RoleDisplay = ({ role, isKilledFirst }: { role: string, isKilledFirst?: boolean }) => {
    let roleElement: JSX.Element;
    switch (role) {
      case "peaceful":
        roleElement = <span>Мирный</span>;
        break;
      case "sheriff":
        roleElement = (
          <span className="flex items-center">
            Шериф <Star className="ml-1 text-yellow-500" size={16} />
          </span>
        );
        break;
      case "mafia":
        roleElement = (
          <span className="flex items-center">
            Мафия <ThumbsDown className="ml-1" size={16} />
          </span>
        );
        break;
      case "don":
        roleElement = (
          <span className="flex items-center">
            Дон <Crown className="ml-1" size={16} />
          </span>
        );
        break;
      default:
        roleElement = <span>{role}</span>;
    }
    return (
      <span className="flex items-center">
        {roleElement}
        {isKilledFirst && <Crosshair className="ml-1.5 text-red-600" size={16} />}
      </span>
    );
  };

  if (isLoading) return <div className="p-4">Загрузка...</div>;
  if (error) return <div className="p-4 text-red-500">Ошибка: {error.message}</div>;

  const games = (data?.games && Array.isArray(data.games))
    ? data.games.map((game: Game) => ({
        ...game,
        players: game.players.filter((player: Player | null): player is Player => player !== null && player !== undefined),
      }))
    : [];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Все игры</h2>
      {games.length === 0 ? (
        <p>Нет данных об играх</p>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-4">
          {games.map((game: Game) => {
            const leadPlayer = game.players.find((p: Player) => p.is_lead);
            const playersInTable = game.players.filter((player: Player) => !player.is_lead && player.nickname);
            const bestMoverNumbers = game.best_movers
              ?.map((bestMoverNickname: string) => {
                const playerIndex = playersInTable.findIndex((player: Player) => player.nickname === bestMoverNickname);
                return playerIndex !== -1 ? playerIndex + 1 : null;
              })
              .filter((number: number | null): number is number => number !== null);
            return (
              <div key={game.game_id} className="flex flex-col">
                <div
                  className="border rounded-lg overflow-hidden transition-all"
                  onClick={() => toggleGameExpand(game.game_id)}
                >
                  <div className="p-4 flex justify-between items-center cursor-pointer">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <Trophy
                          className={game.winner === "peaceful" ? "text-red-500" : ""}
                          size={20}
                        />
                        <span>{formatDate(game.game_date)}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Landmark size={14} />
                        <span>Стол: {game.table_number}</span>
                        <Hash size={14} className="ml-2" />
                        <span>Игра: {game.game_number}</span>
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      {game.winner === "peaceful" ? "Мирные" : "Мафия"}
                    </div>
                  </div>
                  {expandedGames[game.game_id] && (
                    <div className="p-4 border-t mt-2 relative">
                      <div className="mb-4 flex flex-wrap items-center gap-x-4">
                        <p className="font-medium">
                          Ведущий: {leadPlayer?.nickname || "Не указан"}
                        </p>
                        {bestMoverNumbers && bestMoverNumbers.length > 0 && (
                          <p className="absolute text-sm text-gray-500 right-4">
                            ЛХ: {bestMoverNumbers.join(' ')}
                          </p>
                        )}
                      </div>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>№</TableHead>
                            <TableHead>Ник</TableHead>
                            <TableHead>Роль</TableHead>
                            <TableHead>Баллы</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {playersInTable.map((player: Player, index: number) => (
                              <TableRow key={`${game.game_id}-${player.id}`}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell>{player.nickname}</TableCell>
                                <TableCell>
                                  <RoleDisplay role={player.role} isKilledFirst={player.is_killed_first} />
                                </TableCell>
                                <TableCell>
                                  {player.score > 0 ? player.score : ""}
                                </TableCell>
                              </TableRow>
                            ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

import { useEffect, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Trophy, Star, ThumbsDown, Crown, Hash, Landmark, Crosshair } from "lucide-react"; // Импортируем Crosshair
import useSWR from 'swr';
import Cookies from 'js-cookie';
import API_BASE_URL from "@/lib/server";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationPrevious,
  PaginationNext,
  PaginationEllipsis,
} from "@/components/ui/pagination";
import { Select, SelectGroup, SelectValue, SelectTrigger, SelectContent, SelectLabel, SelectItem } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

interface Player {
  id: number;
  nickname: string;
  role: string;
  score: number;
  is_lead: boolean;
  is_killed_first?: boolean;
}

interface Game {
  game_id: number;
  game_date: string;
  winner: string;
  table_number: number;
  game_number: number;
  players: Player[];
  best_movers?: string[];
}

export function GamesList() {
  const token = Cookies.get('mafiaToken');
  const [page, setPage] = useState(1);
  const limit = 30;
  const offset = (page - 1) * limit;

  const currentYear = new Date().getFullYear();
  const years = ["Любой", ...Array.from({length: currentYear - 2020 + 1}, (_, i) => (2020 + i).toString())];
  const monthsList = [
    "Любой",
    "Январь",
    "Февраль",
    "Март",
    "Апрель",
    "Май",
    "Июнь",
    "Июль",
    "Август",
    "Сентябрь",
    "Октябрь",
    "Ноябрь",
    "Декабрь"
  ];
  const [selectedYear, setSelectedYear] = useState<string>("Любой");
  const [selectedMonth, setSelectedMonth] = useState<string>("Любой");

  // Преобразуем месяц в номер для API
  const monthParam = (selectedMonth !== "Любой" && selectedYear !== "Любой") ? monthsList.indexOf(selectedMonth) : undefined;
  const yearParam = selectedYear !== "Любой" ? parseInt(selectedYear) : undefined;

  const fetcher = async (url: string, body: any, token: string) => {
    // Гарантируем, что limit и offset всегда числа
    const safeBody = {
      ...body,
      limit: typeof body.limit === 'number' && !isNaN(body.limit) ? body.limit : 30,
      offset: typeof body.offset === 'number' && !isNaN(body.offset) ? body.offset : 0,
    };
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(safeBody),
    });
    if (res.status === 401) {
      Cookies.remove('mafiaToken');
      window.location.replace('/login');
      throw new Error('Unauthorized');
    }
    return res.json();
  };

  const { data, error, isLoading, mutate } = useSWR(
    token ? ["/api/games", offset, limit, yearParam, monthParam, token] : null,
    ([_, offset, limit, year, month, token]) => fetcher(`${API_BASE_URL}/api/games`, { offset, limit, year, month }, token),
    { revalidateOnFocus: false }
  );

  const [expandedGames, setExpandedGames] = useState<Record<number, boolean>>({});

  const toggleGameExpand = (gameId: number) => {
    setExpandedGames((prev) => ({
      ...prev,
      [gameId]: !prev[gameId],
    }));
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("ru-RU", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const RoleDisplay = ({ role, isKilledFirst }: { role: string, isKilledFirst?: boolean }) => {
    let roleElement: JSX.Element;
    switch (role) {
      case "peaceful":
        roleElement = <span>Мирный</span>;
        break;
      case "sheriff":
        roleElement = (
          <span className="flex items-center">
            Шериф <Star className="ml-1 text-yellow-500" size={16} />
          </span>
        );
        break;
      case "mafia":
        roleElement = (
          <span className="flex items-center">
            Мафия <ThumbsDown className="ml-1" size={16} />
          </span>
        );
        break;
      case "don":
        roleElement = (
          <span className="flex items-center">
            Дон <Crown className="ml-1" size={16} />
          </span>
        );
        break;
      default:
        roleElement = <span>{role}</span>;
    }
    return (
      <span className="flex items-center">
        {roleElement}
        {isKilledFirst && <Crosshair className="ml-1.5 text-red-600" size={16} />}
      </span>
    );
  };

  if (error) return <div className="p-4 text-red-500">Ошибка: {error.message}</div>;

  // Скелетоны для загрузки
  const loadingSkeleton = (
    <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-4">
      {Array.from({ length: 6 }).map((_, idx) => (
        <div key={idx} className="flex flex-col">
          <div className="border rounded-lg overflow-hidden">
            <div className="p-4 flex justify-between items-center">
              <div className="flex flex-col gap-1 w-full">
                <div className="flex items-center gap-2">
                  <Skeleton className="h-5 w-5" />
                  <Skeleton className="h-4 w-32" />
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Skeleton className="h-3 w-16" />
                  <Skeleton className="h-3 w-16 ml-2" />
                  <Skeleton className="h-3 w-16 ml-2" />
                </div>
              </div>
              <Skeleton className="h-4 w-16" />
            </div>
            <div className="p-4 border-t mt-2">
              <div className="mb-4 flex flex-wrap items-center gap-x-4">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-3 w-12 ml-4" />
              </div>
              <div>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const games = (data?.games && Array.isArray(data.games))
    ? data.games.map((game: Game) => ({
        ...game,
        players: game.players.filter((player: Player | null): player is Player => player !== null && player !== undefined),
      }))
    : [];

  // Пагинация
  const total = data?.total || 0;
  const totalPages = Math.ceil(total / limit);

  // Генерация массива страниц для пагинации (с ... если страниц много)
  function getPageNumbers(current: number, total: number) {
    const delta = 2;
    const range = [];
    for (let i = Math.max(2, current - delta); i <= Math.min(total - 1, current + delta); i++) {
      range.push(i);
    }
    if (current - delta > 2) range.unshift('...');
    if (current + delta < total - 1) range.push('...');
    range.unshift(1);
    if (total > 1) range.push(total);
    return Array.from(new Set(range));
  }

  return (
    <div className="p-4">
      <div className="flex flex-wrap items-center gap-4 mb-4">
        <h2 className="text-xl font-bold">Все игры</h2>
        <Select value={selectedYear} onValueChange={v => { setSelectedYear(v); setPage(1); }}>
          <SelectTrigger className="w-[110px]">
            <SelectValue placeholder="Год" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectLabel>Год</SelectLabel>
              {years.map(y => (
                <SelectItem key={y} value={y}>{y}</SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
        <Select value={selectedMonth} onValueChange={v => { setSelectedMonth(v); setPage(1); }}>
          <SelectTrigger className="w-[130px]">
            <SelectValue placeholder="Месяц" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectLabel>Месяц</SelectLabel>
              {monthsList.map(m => (
                <SelectItem key={m} value={m}>{m}</SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
      {isLoading ? (
        loadingSkeleton
      ) : games.length === 0 ? (
        <p>Нет данных об играх</p>
      ) : (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-4">
            {games.map((game: Game) => {
              const leadPlayer = game.players.find((p: Player) => p.is_lead);
              const playersInTable = game.players.filter((player: Player) => !player.is_lead && player.nickname);
              const bestMoverNumbers = game.best_movers
                ?.map((bestMoverNickname: string) => {
                  const playerIndex = playersInTable.findIndex((player: Player) => player.nickname === bestMoverNickname);
                  return playerIndex !== -1 ? playerIndex + 1 : null;
                })
                .filter((number: number | null): number is number => number !== null);
              return (
                <div key={game.game_id} className="flex flex-col">
                  <div
                    className="border rounded-lg overflow-hidden transition-all"
                    onClick={() => toggleGameExpand(game.game_id)}
                  >
                    <div className="p-4 flex justify-between items-center cursor-pointer">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          <Trophy
                            className={game.winner === "peaceful" ? "text-red-500" : ""}
                            size={20}
                          />
                          <span>{formatDate(game.game_date)}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Landmark size={14} />
                          <span>Стол: {game.table_number}</span>
                          <Hash size={14} className="ml-2" />
                          <span>Игра: {game.game_number}</span>
                        </div>
                      </div>
                      <div className="text-sm text-gray-500">
                        {game.winner === "peaceful" ? "Мирные" : "Мафия"}
                      </div>
                    </div>
                    {expandedGames[game.game_id] && (
                      <div className="p-4 border-t mt-2 relative">
                        <div className="mb-4 flex flex-wrap items-center gap-x-4">
                          <p className="font-medium">
                            Ведущий: {leadPlayer?.nickname || "Не указан"}
                          </p>
                          {bestMoverNumbers && bestMoverNumbers.length > 0 && (
                            <p className="absolute text-sm text-gray-500 right-4">
                              ЛХ: {bestMoverNumbers.join(' ')}
                            </p>
                          )}
                        </div>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>№</TableHead>
                              <TableHead>Ник</TableHead>
                              <TableHead>Роль</TableHead>
                              <TableHead>Баллы</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {playersInTable.map((player: Player, index: number) => (
                                <TableRow key={`${game.game_id}-${player.id}`}>
                                  <TableCell>{index + 1}</TableCell>
                                  <TableCell>{player.nickname}</TableCell>
                                  <TableCell>
                                    <RoleDisplay role={player.role} isKilledFirst={player.is_killed_first} />
                                  </TableCell>
                                  <TableCell>
                                    {player.score > 0 ? player.score : ""}
                                  </TableCell>
                                </TableRow>
                              ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {totalPages > 1 && (
            <Pagination className="mt-6">
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    onClick={() => setPage(page - 1)}
                    aria-disabled={page === 1}
                    tabIndex={page === 1 ? -1 : 0}
                    style={{ pointerEvents: page === 1 ? 'none' : undefined }}
                  />
                </PaginationItem>
                {getPageNumbers(page, totalPages).map((p, idx) =>
                  p === '...'
                    ? <PaginationItem key={"ellipsis-" + idx}><PaginationEllipsis /></PaginationItem>
                    : <PaginationItem key={p}>
                        <PaginationLink
                          isActive={p === page}
                          onClick={() => typeof p === 'number' && setPage(p)}
                          aria-current={p === page ? 'page' : undefined}
                        >
                          {p}
                        </PaginationLink>
                      </PaginationItem>
                )}
                <PaginationItem>
                  <PaginationNext
                    onClick={() => setPage(page + 1)}
                    aria-disabled={page === totalPages}
                    tabIndex={page === totalPages ? -1 : 0}
                    style={{ pointerEvents: page === totalPages ? 'none' : undefined }}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}
    </div>
  );
}

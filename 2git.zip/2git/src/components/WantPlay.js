import React, { useState, useEffect } from'react';
import '../index.css';
import { Nav } from "./Navs";
import Globe from 'react-globe.gl';
import 'd3-array';
import * as d3 from 'd3-scale';

export const Wantplay = () => {
  const { useState, useEffect } = React;
  const [landingSites, setLandingSites] = useState([]);
  const colorScale = d3.scaleOrdinal(['orangered', 'mediumblue', 'darkgreen', 'yellow']);
    useEffect(() => {
      fetch('https://raw.githubusercontent.com/kodj11/maf_comp/refs/heads/main/landings.json')
        .then(r =>r.json())
        .then(setLandingSites);
    }, []);
  const labelsTopOrientation = new Set(['GATTI', 'TITAN']);
  const [globeImageUrl, setGlobeImageUrl] = useState('');

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour >= 6 && hour < 18) {
      setGlobeImageUrl("https://raw.githubusercontent.com/kodj11/maf_comp/refs/heads/main/world.200409.3x5400x2700.jpg");
    } else {
      setGlobeImageUrl("https://raw.githubusercontent.com/kodj11/maf_comp/refs/heads/main/earth-night.jpg");
    }
  }, []);
  return (
    <>
      <Nav transparent />
      <Globe 
      globeImageUrl={globeImageUrl}
      backgroundImageUrl="https://raw.githubusercontent.com/kodj11/maf_comp/refs/heads/main/night-sky.png"
      showGraticules={true}
      labelsData={landingSites}
      labelText="label"
      labelSize={1.12}
      labelDotRadius={0.45}
      labelDotOrientation={d => labelsTopOrientation.has(d.label) ? 'top' : 'bottom'}
      labelColor={d => colorScale(d.agency)}
      labelLabel={d => `
        <div><b>${d.label}</b></div>
        <div>Город ${d.city}</div>
        <div>Адресс ${d.address}</div> 
        <div>Нажми чтобы попасть в группу ВК</div>
      `}
      onLabelClick={d => window.open(d.url, '_blank')}
      />
    </>
  );
};